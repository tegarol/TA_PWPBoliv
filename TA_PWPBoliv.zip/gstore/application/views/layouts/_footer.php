<footer class="footer mt-5">
	<nav class="navbar navbar-dark bg-light sticky-bottom">
		<div class="container d-flex justify-content-center">
			<div class="copyright text-info p-3">
				<small class="text-info p-3">Copyright &copy; G.STORE 2021 | Repost by OlipSita 
				</small>
			</div>
		</div>
	</nav>	
</footer>  
